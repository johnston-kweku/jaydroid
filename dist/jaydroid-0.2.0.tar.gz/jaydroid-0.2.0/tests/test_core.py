from jaydroid.core import device, swipe, tap, button


device.connect()

device.reboot()
