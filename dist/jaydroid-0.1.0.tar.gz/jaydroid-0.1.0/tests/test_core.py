from jaydroid.core import device, swipe, button, tap

device.connect()


print(device.battery_info()['temperature'])
